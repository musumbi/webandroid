##Disclaimer

This Open Source project is in no way related to Whatsapp or Facebook, it's just a sample application for chats based on an universally recognized interface for faster understending of its functionalities.

##Android Chat Starter (Original description)

A sample Android App which can be used as a starter application for a chat application.

###What it includes?

* Native Emoji Keyboard - Same as found in WhatsApp
* Chat bubbles - Modeled after WhatsApp

###Screenshots

<img src="https://github.com/DeromirNeves/whatsapp-android/blob/gh-pages/chat1.png"/>
<img src="https://github.com/DeromirNeves/whatsapp-android/blob/gh-pages/chat2.png"/>