package in.co.madhur.chatbubblesdemo;

/**
 * Created by madhur on 3/1/15.
 */
public class Constants {

    public static final String TAG="chatbubbles";
}
